GhostTrailsMax2009_32.dlm : for 3dsmax2009 32-bit
GhostTrailsMax2009_64.dlm : for 3dsmax2009 64-bit
GhostTrailsMax9_64.dlm	  : for 3dsmax9 and 3dsmax2008 64-bit
GhostTrailsMax9_32.dlm    : for 3dsmax9 and 3dsmax2008 32-bit
GhostTrailsMax6.dlm       : for 3dsmax6, 3dsmax7 and 3dsmax8

